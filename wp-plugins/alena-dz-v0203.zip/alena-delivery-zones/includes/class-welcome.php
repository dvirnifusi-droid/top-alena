<?php
if (!defined('ABSPATH')) exit;

/**
 * Welcome / onboarding overlay shown to first-time visitors.
 *
 * Two steps:
 *   1. Pick fulfillment (delivery vs pickup) + address (if delivery)
 *   2. Club options: login / register / continue as guest
 *
 * Persists the choice in WC session so checkout pre-fills it, and in a
 * sessionStorage flag so it doesn't re-appear on every page navigation.
 */
class Alena_DZ_Welcome {

    const SESS_KEY_MODE     = 'alena_fulfillment_mode';
    const SESS_KEY_ADDRESS  = 'alena_initial_address';

    public function __construct() {
        add_action('wp_enqueue_scripts',               [$this, 'enqueue']);
        add_action('wp_ajax_alena_welcome_save',       [$this, 'ajax_save']);
        add_action('wp_ajax_nopriv_alena_welcome_save',[$this, 'ajax_save']);
    }

    /**
     * Whether to show the welcome screen instead of the regular /shop content.
     * Returns false if the customer already picked a fulfillment mode in this session
     * OR if they explicitly skipped the gate.
     */
    public static function should_show(): bool {
        if (function_exists('is_admin') && is_admin()) return false;
        if (!function_exists('WC') || !WC()->session) return true;
        $mode = WC()->session->get(self::SESS_KEY_MODE);
        return empty($mode);
    }

    public function enqueue() {
        if (is_admin()) return;
        wp_enqueue_style('alena-welcome',  ALENA_DZ_URL . 'assets/welcome.css', [], ALENA_DZ_VERSION);
        wp_enqueue_script('alena-welcome', ALENA_DZ_URL . 'assets/welcome.js',  ['jquery'], ALENA_DZ_VERSION, true);
        wp_localize_script('alena-welcome', 'AlenaWelcome', [
            'ajaxUrl'  => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('alena_welcome'),
            'shopUrl'  => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '/shop/',
            'accountUrl' => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : '/my-account/',
        ]);
    }

    public function render() {
        $site_icon = get_site_icon_url(160);
        // Hero image URL — try a hero attachment by name or fall back to a known wp upload path
        $hero_url  = $this->hero_image_url();
        ?>
        <section class="alena-welcome-page" id="alena-welcome" dir="rtl">
          <div class="alena-welcome-photo" <?php if ($hero_url): ?>style="background-image:url('<?php echo esc_url($hero_url); ?>')"<?php endif; ?>></div>
          <div class="alena-welcome-pane">
          <div class="alena-welcome-card">

            <div class="alena-welcome-logo">
              <?php if ($site_icon): ?>
                <img src="<?php echo esc_url($site_icon); ?>" alt="עלינא בפיתה" />
              <?php else: ?>
                <div class="alena-welcome-mark">עלינא</div>
              <?php endif; ?>
              <div class="alena-welcome-tagline">מטבח ים-תיכוני שמח וצבעוני</div>
            </div>

            <!-- Step 1: fulfillment + address -->
            <div class="alena-welcome-step" data-step="1">
              <h2 class="alena-welcome-title">ברוכים הבאים!</h2>
              <p class="alena-welcome-sub">איך תעדיפו לקבל את ההזמנה?</p>

              <div class="alena-welcome-modes">
                <button type="button" class="alena-welcome-mode" data-mode="pickup">
                  <span class="alena-welcome-mode-icon" aria-hidden="true">🥡</span>
                  <span class="alena-welcome-mode-label">איסוף עצמי</span>
                  <span class="alena-welcome-mode-sub">~15-25 דק'</span>
                </button>
                <button type="button" class="alena-welcome-mode is-active" data-mode="delivery">
                  <span class="alena-welcome-mode-icon" aria-hidden="true">🛵</span>
                  <span class="alena-welcome-mode-label">משלוח</span>
                  <span class="alena-welcome-mode-sub">~40-60 דק'</span>
                </button>
              </div>

              <div class="alena-welcome-address" id="alena-welcome-address">
                <label for="alena-welcome-address-input">כתובת מלאה למשלוח</label>
                <input type="text"
                       id="alena-welcome-address-input"
                       placeholder="לדוגמה: הרצל 123, ראשון לציון"
                       autocomplete="street-address" />
                <p class="alena-welcome-address-hint">משלוחים לראשון לציון, משמר השבעה ובית דגן</p>
              </div>

              <button type="button" class="alena-welcome-next" id="alena-welcome-next">המשך</button>
            </div>

            <!-- Step 2: club -->
            <div class="alena-welcome-step" data-step="2" hidden>
              <h2 class="alena-welcome-title">התחברות למערכת</h2>
              <p class="alena-welcome-sub">חברי מועדון צוברים ופודים בכל הזמנה — בחר איך להתחיל</p>

              <button type="button" class="alena-welcome-option" data-action="login">
                <span class="alena-welcome-option-icon" aria-hidden="true">📱</span>
                <span class="alena-welcome-option-label">התחברות כחבר מועדון</span>
              </button>
              <button type="button" class="alena-welcome-option" data-action="register">
                <span class="alena-welcome-option-icon" aria-hidden="true">📝</span>
                <span class="alena-welcome-option-label">הרשמה למועדון הלקוחות</span>
              </button>
              <button type="button" class="alena-welcome-option alena-welcome-option-ghost" data-action="skip">
                <span class="alena-welcome-option-icon" aria-hidden="true">→</span>
                <span class="alena-welcome-option-label">המשך ללא התחברות</span>
              </button>
            </div>

          </div>
          </div>
        </section>
        <?php
    }

    /**
     * Best-effort lookup for a hero food image to use as the left-half photo.
     * Prefers an image titled "alena-welcome-hero" in the media library, then
     * the site logo, then nothing (CSS gradient fallback).
     */
    private function hero_image_url(): string {
        // Look for an explicit hero image
        $hero = get_posts([
            'post_type'   => 'attachment',
            'post_status' => 'inherit',
            'title'       => 'alena-welcome-hero',
            'numberposts' => 1,
        ]);
        if (!empty($hero)) {
            $url = wp_get_attachment_image_url($hero[0]->ID, 'full');
            if ($url) return $url;
        }
        // Otherwise look for a product image from the "פיתות עלינא" / "בצלחת" category
        $products = get_posts([
            'post_type'   => 'product',
            'numberposts' => 1,
            'meta_query'  => [['key' => '_thumbnail_id', 'compare' => 'EXISTS']],
            'tax_query'   => [[
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => ['pitot-alena', 'pitot', 'platot', 'plates'],
            ]],
        ]);
        if (!empty($products)) {
            $url = get_the_post_thumbnail_url($products[0]->ID, 'full');
            if ($url) return $url;
        }
        return '';
    }

    public function ajax_save() {
        check_ajax_referer('alena_welcome', 'nonce');
        $mode    = isset($_POST['mode']) ? sanitize_text_field((string) $_POST['mode']) : '';
        $address = isset($_POST['address']) ? sanitize_text_field((string) $_POST['address']) : '';
        if (!in_array($mode, ['delivery', 'pickup'], true)) {
            wp_send_json_error('bad_mode', 400);
        }
        if (function_exists('WC') && WC()->session) {
            WC()->session->set(self::SESS_KEY_MODE,    $mode);
            WC()->session->set(self::SESS_KEY_ADDRESS, $address);
            // Also feed into the existing fulfillment system if present
            $methods = ($mode === 'pickup') ? ['local_pickup'] : ['alena_polygon'];
            WC()->session->set('chosen_shipping_methods', $methods);
        }
        wp_send_json_success(['mode' => $mode]);
    }
}
