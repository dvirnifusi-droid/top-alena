(function ($) {
  'use strict';

  const $phoneForm = $('#alena-otp-step-phone');
  const $codeForm  = $('#alena-otp-step-code');
  const $phoneIn   = $('#alena-otp-phone');
  const $codeIn    = $('#alena-otp-code');
  const $shown     = $('#alena-otp-shown-phone');
  const $resend    = $('#alena-otp-resend');
  const $change    = $('#alena-otp-change-phone');
  const $errPhone  = $('#alena-otp-phone-error');
  const $errCode   = $('#alena-otp-code-error');
  const $cool      = $('#alena-otp-cooldown');
  const $coolSec   = $('#alena-otp-cooldown-sec');

  if (!$phoneForm.length) return;

  let cooldownTimer = null;
  function startCooldown(sec) {
    let n = sec || 60;
    $cool.removeAttr('hidden');
    $coolSec.text(n);
    $resend.css('pointer-events', 'none').css('opacity', 0.5);
    if (cooldownTimer) clearInterval(cooldownTimer);
    cooldownTimer = setInterval(function () {
      n--;
      $coolSec.text(n);
      if (n <= 0) {
        clearInterval(cooldownTimer);
        $cool.attr('hidden', true);
        $resend.css('pointer-events', '').css('opacity', '');
      }
    }, 1000);
  }

  function showError($el, msg) { $el.text(msg).removeAttr('hidden'); }
  function hideError($el)      { $el.attr('hidden', true).text(''); }

  function showDevBanner(code, notice) {
    let $b = $('#alena-otp-dev-banner');
    if (!$b.length) {
      $b = $('<div id="alena-otp-dev-banner" class="alena-otp-dev"></div>');
      $codeForm.prepend($b);
    }
    $b.html(
      '<strong>🛠️ ' + (notice || 'מצב פיתוח') + '</strong>' +
      '<div class="alena-otp-dev-code">' + code + '</div>' +
      '<div class="alena-otp-dev-hint">הוקלד אוטומטית למטה — לחץ "התחבר ✓"</div>'
    );
  }

  function normalize(raw) { return (raw || '').replace(/\D/g, ''); }

  function sendCode(phone) {
    return $.ajax({
      url: AlenaPhoneAuth.apiUrl + 'send',
      method: 'POST',
      headers: { 'X-WP-Nonce': AlenaPhoneAuth.nonce },
      data: { phone: phone }
    });
  }

  function verifyCode(phone, code) {
    return $.ajax({
      url: AlenaPhoneAuth.apiUrl + 'verify',
      method: 'POST',
      headers: { 'X-WP-Nonce': AlenaPhoneAuth.nonce },
      data: { phone: phone, code: code }
    });
  }

  $phoneForm.on('submit', function (e) {
    e.preventDefault();
    hideError($errPhone);
    const phone = normalize($phoneIn.val());
    if (!/^0\d{8,9}$/.test(phone)) {
      showError($errPhone, 'מספר לא תקין — לדוגמה 0501234567');
      return;
    }
    const $btn = $(this).find('.alena-otp-cta');
    const orig = $btn.text();
    $btn.prop('disabled', true).text('שולח…');

    sendCode(phone)
      .done(function (r) {
        $btn.prop('disabled', false).text(orig);
        if (!r || !r.ok) {
          showError($errPhone, (r && r.message) || 'שליחה נכשלה');
          return;
        }
        $shown.text(phone);
        $phoneForm.attr('hidden', true);
        $codeForm.removeAttr('hidden');
        // DEV / Console mode — show the code on screen so the user can self-test
        if (r.dev_code) {
          showDevBanner(r.dev_code, r.dev_notice);
          $codeIn.val(r.dev_code); // pre-fill for one-click verify
        }
        setTimeout(function () { $codeIn.trigger('focus'); }, 100);
        startCooldown(60);
      })
      .fail(function (xhr) {
        $btn.prop('disabled', false).text(orig);
        const r = xhr.responseJSON || {};
        showError($errPhone, r.message || ('שליחה נכשלה (HTTP ' + xhr.status + ')'));
      });
  });

  $codeForm.on('submit', function (e) {
    e.preventDefault();
    hideError($errCode);
    const code  = normalize($codeIn.val());
    const phone = normalize($phoneIn.val());
    if (code.length < 4) {
      showError($errCode, 'הכנס את הקוד שקיבלת');
      return;
    }
    const $btn = $(this).find('.alena-otp-cta');
    const orig = $btn.text();
    $btn.prop('disabled', true).text('מתחבר…');

    verifyCode(phone, code)
      .done(function (r) {
        if (r && r.ok) {
          $btn.text('✓ מתחבר…');
          window.location.href = r.redirect || AlenaPhoneAuth.accountUrl;
        } else {
          $btn.prop('disabled', false).text(orig);
          showError($errCode, (r && r.message) || 'שגיאה');
        }
      })
      .fail(function (xhr) {
        $btn.prop('disabled', false).text(orig);
        const r = xhr.responseJSON || {};
        showError($errCode, r.message || ('קוד שגוי (HTTP ' + xhr.status + ')'));
      });
  });

  $resend.on('click', function (e) {
    e.preventDefault();
    if ($resend.css('pointer-events') === 'none') return;
    const phone = normalize($phoneIn.val());
    if (!phone) return;
    sendCode(phone).done(function () { startCooldown(60); });
  });

  $change.on('click', function (e) {
    e.preventDefault();
    if (cooldownTimer) clearInterval(cooldownTimer);
    $codeForm.attr('hidden', true);
    $phoneForm.removeAttr('hidden');
    $phoneIn.trigger('focus');
    hideError($errPhone);
    hideError($errCode);
    $codeIn.val('');
  });

  // Auto-format Israeli phone as user types
  $phoneIn.on('input', function () {
    let v = normalize($(this).val());
    if (v.length > 10) v = v.slice(0, 10);
    $(this).val(v);
  });
  $codeIn.on('input', function () {
    let v = normalize($(this).val());
    if (v.length > 6) v = v.slice(0, 6);
    $(this).val(v);
    if (v.length === 6) $codeForm.trigger('submit');
  });
})(jQuery);
