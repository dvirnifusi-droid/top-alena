<?php
/**
 * Phone+OTP login template — overrides WooCommerce's default form-login.php
 *
 * Two-step UI:
 *   1. Phone entry → "שלח קוד"
 *   2. Code entry → "התחבר"
 *
 * Powered by the REST endpoints in class-phone-auth.php.
 */
if (!defined('ABSPATH')) exit;

do_action('woocommerce_before_customer_login_form');
?>

<div class="alena-otp-wrap" dir="rtl">
  <div class="alena-otp-card">
    <div class="alena-otp-emoji" aria-hidden="true">📱</div>
    <h2 class="alena-otp-title">התחברות מהירה</h2>
    <p class="alena-otp-sub">תכניסו טלפון, נשלח לכם קוד בוואטסאפ</p>

    <!-- Step 1: phone -->
    <form class="alena-otp-form" id="alena-otp-step-phone" autocomplete="off" novalidate>
      <label class="alena-otp-label">מספר טלפון
        <input type="tel"
               inputmode="tel"
               name="phone"
               id="alena-otp-phone"
               placeholder="050-1234567"
               autocomplete="tel"
               required
               dir="ltr" />
      </label>
      <button type="submit" class="alena-otp-cta">שלחו לי קוד ←</button>
      <p class="alena-otp-error" id="alena-otp-phone-error" hidden></p>
    </form>

    <!-- Step 2: code -->
    <form class="alena-otp-form" id="alena-otp-step-code" autocomplete="off" novalidate hidden>
      <p class="alena-otp-step-info">
        שלחנו קוד 6 ספרות ל-<strong id="alena-otp-shown-phone"></strong>
        · <a href="#" id="alena-otp-change-phone">שנה מספר</a>
      </p>
      <label class="alena-otp-label">קוד אימות
        <input type="text"
               inputmode="numeric"
               pattern="\d{6}"
               maxlength="6"
               name="code"
               id="alena-otp-code"
               placeholder="123456"
               autocomplete="one-time-code"
               required
               dir="ltr" />
      </label>
      <button type="submit" class="alena-otp-cta">התחבר ✓</button>
      <p class="alena-otp-meta">
        לא קיבלתם? <a href="#" id="alena-otp-resend">שלחו שוב</a>
        <span id="alena-otp-cooldown" hidden> · בעוד <span id="alena-otp-cooldown-sec">60</span> שניות</span>
      </p>
      <p class="alena-otp-error" id="alena-otp-code-error" hidden></p>
    </form>

    <p class="alena-otp-legal">
      בהמשך אתם מסכימים ל<a href="<?php echo esc_url(get_privacy_policy_url() ?: '#'); ?>">תקנון ומדיניות הפרטיות</a>
    </p>
  </div>
</div>

<?php do_action('woocommerce_after_customer_login_form'); ?>
