<?php
if (!defined('ABSPATH')) exit;

/**
 * TOPALENA Customer Club integration.
 *
 * Hooks into the WP plugin to:
 *   1. On order completion, POST /api/club/orders to award coins (100₪ = 1 coin).
 *   2. During checkout, look up the phone in /api/club/lookup — show points balance / club tier.
 *   3. On My Account page, render the club card with current balance + tier + perks.
 *   4. Allow club join via a CTA at checkout (POST /api/club/register).
 *   5. Future: phone-OTP-based login (WhatsApp Cloud API or Twilio).
 *
 * Settings stored as WP options under `alena_club_*`:
 *   - alena_club_api_base   (e.g. https://topalena.com)
 *   - alena_club_api_key    (CLUB_API_KEY value on the TOPALENA API)
 *   - alena_club_coin_value (₪ per redeemed coin; default 4)
 *   - alena_club_earn_per   (₪ per earned coin; default 100)
 */
class Alena_DZ_Club {

    const OPT_BASE      = 'alena_club_api_base';
    const OPT_KEY       = 'alena_club_api_key';
    const OPT_COIN_VAL  = 'alena_club_coin_value';
    const OPT_EARN_PER  = 'alena_club_earn_per';

    public function __construct() {
        add_action('admin_menu',                       [$this, 'menu'], 28);
        add_action('admin_init',                       [$this, 'register_settings']);
        add_action('wp_enqueue_scripts',               [$this, 'enqueue']);

        // Award points on order completion
        add_action('woocommerce_order_status_completed',  [$this, 'on_order_complete'], 10, 1);
        add_action('woocommerce_order_status_processing', [$this, 'on_order_complete'], 10, 1);

        // My Account widget — show points balance, tier, perks
        add_action('woocommerce_account_dashboard',    [$this, 'render_club_widget'], 8);

        // Checkout — lookup club status when phone is entered
        add_action('wp_ajax_alena_club_lookup',        [$this, 'ajax_lookup']);
        add_action('wp_ajax_nopriv_alena_club_lookup', [$this, 'ajax_lookup']);
        add_action('wp_ajax_alena_club_register',      [$this, 'ajax_register']);
        add_action('wp_ajax_nopriv_alena_club_register',[$this, 'ajax_register']);
    }

    public function enqueue() {
        if (function_exists('is_account_page') && (is_account_page() || is_checkout() || is_cart())) {
            wp_enqueue_style('alena-club',  ALENA_DZ_URL . 'assets/club.css', [], ALENA_DZ_VERSION);
            wp_enqueue_script('alena-club', ALENA_DZ_URL . 'assets/club.js',  ['jquery'], ALENA_DZ_VERSION, true);
        }
    }

    public static function api_base(): string {
        $base = (string) get_option(self::OPT_BASE, 'https://topalena.com');
        return rtrim($base, '/');
    }

    public static function api_key(): string {
        return (string) get_option(self::OPT_KEY, '');
    }

    public static function coin_value_ils(): float {
        $v = (float) get_option(self::OPT_COIN_VAL, 4);
        return $v > 0 ? $v : 4.0;
    }

    public static function earn_per_ils(): float {
        $v = (float) get_option(self::OPT_EARN_PER, 100);
        return $v > 0 ? $v : 100.0;
    }

    public static function is_configured(): bool {
        return self::api_base() !== '' && self::api_key() !== '';
    }

    /* ===========================================================
       HTTP — talk to TOPALENA club API
       =========================================================== */

    private function api_request(string $path, string $method = 'GET', array $body = null): array {
        if (!self::is_configured()) {
            return ['ok' => false, 'error' => 'club_not_configured'];
        }
        $url = self::api_base() . $path;
        $args = [
            'method'  => $method,
            'timeout' => 12,
            'headers' => [
                'X-Alena-Club-Key' => self::api_key(),
                'Accept'           => 'application/json',
            ],
        ];
        if ($body !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body);
        }
        $resp = wp_remote_request($url, $args);
        if (is_wp_error($resp)) {
            return ['ok' => false, 'error' => 'network', 'detail' => $resp->get_error_message()];
        }
        $code = wp_remote_retrieve_response_code($resp);
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        return [
            'ok'   => $code >= 200 && $code < 300,
            'code' => $code,
            'data' => is_array($data) ? $data : null,
        ];
    }

    public function lookup_phone(string $phone): ?array {
        $r = $this->api_request('/api/club/lookup', 'POST', ['phone' => $phone]);
        if (!$r['ok']) return null;
        return $r['data'];
    }

    public function register_phone(string $phone, string $name = '', bool $consent = true): ?array {
        $r = $this->api_request('/api/club/register', 'POST', [
            'phone'             => $phone,
            'name'              => $name,
            'marketing_consent' => $consent,
        ]);
        if (!$r['ok']) return null;
        return $r['data'];
    }

    public function record_order(string $phone, float $total, string $order_id): ?array {
        $r = $this->api_request('/api/club/orders', 'POST', [
            'phone'       => $phone,
            'order_total' => $total,
            'order_id'    => $order_id,
        ]);
        if (!$r['ok']) return null;
        return $r['data'];
    }

    public function get_benefits(string $phone): array {
        $phone = preg_replace('/\D/', '', $phone);
        $r = $this->api_request('/api/club/benefits/' . $phone);
        if (!$r['ok']) return [];
        return $r['data']['benefits'] ?? [];
    }

    /* ===========================================================
       Order lifecycle
       =========================================================== */

    public function on_order_complete($order_id) {
        try {
            if (!self::is_configured()) return;
            $order = wc_get_order($order_id);
            if (!$order) return;

            $already = $order->get_meta('_alena_club_awarded');
            if ($already) return; // idempotent — never double-award

            $phone = (string) $order->get_billing_phone();
            if (!$phone) return;

            $total = (float) $order->get_total();
            $resp = $this->record_order($phone, $total, (string) $order_id);
            if (!$resp || !isset($resp['coins_earned'])) return;

            $order->update_meta_data('_alena_club_awarded',       1);
            $order->update_meta_data('_alena_club_coins_earned',  (int) $resp['coins_earned']);
            $order->update_meta_data('_alena_club_balance_after', (int) ($resp['new_balance'] ?? 0));
            $order->update_meta_data('_alena_club_tier',          (string) ($resp['new_tier'] ?? ''));
            $order->save();

            $order->add_order_note(sprintf(
                '🎁 מועדון TOPALENA: %d נקודות צבירה הוענקו. יתרה: %d (%s)',
                (int) $resp['coins_earned'],
                (int) ($resp['new_balance'] ?? 0),
                (string) ($resp['new_tier'] ?? '')
            ));
        } catch (\Throwable $e) {
            // Swallow — club integration failures should NEVER break order processing
            if (function_exists('error_log')) {
                error_log('Alena_DZ_Club::on_order_complete error: ' . $e->getMessage());
            }
        }
    }

    /* ===========================================================
       My Account widget
       =========================================================== */

    public function render_club_widget() {
        if (!self::is_configured()) return;

        $phone = '';
        $user_id = get_current_user_id();
        if ($user_id) {
            $phone = get_user_meta($user_id, 'billing_phone', true);
        }
        if (!$phone) return;

        $info = $this->lookup_phone($phone);
        if (!$info || empty($info['found'])) {
            // Show a "join the club" CTA
            $this->render_join_cta($phone);
            return;
        }

        $balance = (int) ($info['coin_balance'] ?? 0);
        $tier    = (string) ($info['loyalty_tier'] ?? 'regular');
        $visits  = (int) ($info['visit_count'] ?? 0);
        $coin_v  = self::coin_value_ils();
        $value_ils = $balance * $coin_v;

        $tier_labels = [
            'regular' => ['name' => 'מועדון רגיל', 'emoji' => '🥙'],
            'silver'  => ['name' => 'כסף',         'emoji' => '🥈'],
            'gold'    => ['name' => 'זהב',         'emoji' => '👑'],
        ];
        $t = $tier_labels[$tier] ?? $tier_labels['regular'];
        ?>
        <div class="alena-club-widget">
          <div class="alena-club-head">
            <span class="alena-club-emoji"><?php echo $t['emoji']; ?></span>
            <div>
              <strong class="alena-club-title">מועדון לקוחות עלינא</strong>
              <span class="alena-club-tier"><?php echo esc_html($t['name']); ?> · <?php echo $visits; ?> הזמנות</span>
            </div>
          </div>
          <div class="alena-club-balance">
            <div class="alena-club-balance-num"><?php echo $balance; ?></div>
            <div class="alena-club-balance-label">נקודות צבירה</div>
            <div class="alena-club-balance-value">שווה ₪<?php echo number_format($value_ils, 0); ?> בקופה</div>
          </div>
          <div class="alena-club-meta">
            כל ₪<?php echo (int) self::earn_per_ils(); ?> בהזמנה = נקודה אחת · כל נקודה שווה ₪<?php echo number_format($coin_v, 0); ?>
          </div>
        </div>
        <?php
    }

    private function render_join_cta(string $phone) {
        $earn_per = (int) self::earn_per_ils();
        $coin_v   = self::coin_value_ils();
        ?>
        <div class="alena-club-widget alena-club-widget-join">
          <div class="alena-club-head">
            <span class="alena-club-emoji">🎁</span>
            <strong class="alena-club-title">הצטרפו למועדון עלינא — חינם</strong>
          </div>
          <p class="alena-club-perks">
            כל ₪<?php echo $earn_per; ?> בהזמנה צוברים נקודה · כל נקודה שווה ₪<?php echo number_format($coin_v, 0); ?> בקופה הבאה ·
            הטבות אישיות ליום הולדת ולחגים
          </p>
          <button type="button"
                  class="alena-club-join-btn"
                  data-phone="<?php echo esc_attr($phone); ?>"
                  data-nonce="<?php echo wp_create_nonce('alena_club_register'); ?>">
            הצטרפות מהירה ↻
          </button>
        </div>
        <?php
    }

    public function ajax_lookup() {
        $phone = isset($_POST['phone']) ? sanitize_text_field((string) $_POST['phone']) : '';
        if (!$phone) wp_send_json_error('no_phone', 400);
        $info = $this->lookup_phone($phone);
        if (!$info) wp_send_json_error('lookup_failed', 502);
        wp_send_json_success($info);
    }

    public function ajax_register() {
        check_ajax_referer('alena_club_register', 'nonce');
        $phone = isset($_POST['phone']) ? sanitize_text_field((string) $_POST['phone']) : '';
        $name  = isset($_POST['name'])  ? sanitize_text_field((string) $_POST['name'])  : '';
        if (!$phone) wp_send_json_error('no_phone', 400);
        $resp = $this->register_phone($phone, $name, true);
        if (!$resp) wp_send_json_error('register_failed', 502);
        wp_send_json_success($resp);
    }

    /* ===========================================================
       Admin settings page
       =========================================================== */

    public function menu() {
        add_submenu_page(
            'alena-delivery-zones',
            'מועדון לקוחות',
            'מועדון לקוחות',
            'manage_woocommerce',
            'alena-club-settings',
            [$this, 'render_admin']
        );
    }

    public function register_settings() {
        register_setting('alena_club', self::OPT_BASE,     ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
        register_setting('alena_club', self::OPT_KEY,      ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field']);
        register_setting('alena_club', self::OPT_COIN_VAL, ['type' => 'number', 'sanitize_callback' => 'floatval']);
        register_setting('alena_club', self::OPT_EARN_PER, ['type' => 'number', 'sanitize_callback' => 'floatval']);
    }

    public function render_admin() {
        $base    = self::api_base();
        $key     = self::api_key();
        $coin_v  = self::coin_value_ils();
        $earn_p  = self::earn_per_ils();
        $ping    = null;
        if (self::is_configured()) {
            $r = $this->api_request('/api/club/ping');
            $ping = $r;
        }
        ?>
        <div class="wrap" dir="rtl">
          <h1>מועדון לקוחות TOPALENA — הגדרות</h1>
          <form method="post" action="options.php">
            <?php settings_fields('alena_club'); ?>
            <table class="form-table">
              <tr>
                <th>כתובת API</th>
                <td>
                  <input type="url" name="<?php echo self::OPT_BASE; ?>" value="<?php echo esc_attr($base); ?>" style="width:420px" placeholder="https://topalena.com" />
                  <p class="description">כתובת השרת של TOPALENA, ללא נתיב. לדוגמה: <code>https://topalena.com</code></p>
                </td>
              </tr>
              <tr>
                <th>מפתח API (CLUB_API_KEY)</th>
                <td>
                  <input type="text" name="<?php echo self::OPT_KEY; ?>" value="<?php echo esc_attr($key); ?>" style="width:420px" />
                  <p class="description">אותו ערך שמוגדר ב-env של TOPALENA כ-<code>CLUB_API_KEY</code></p>
                </td>
              </tr>
              <tr>
                <th>₪ לכל נקודה (פדיון)</th>
                <td>
                  <input type="number" step="0.5" min="0" name="<?php echo self::OPT_COIN_VAL; ?>" value="<?php echo esc_attr($coin_v); ?>" /> ש״ח
                  <p class="description">כמה כל נקודה שווה בקופה. ברירת מחדל: 4</p>
                </td>
              </tr>
              <tr>
                <th>₪ לכל נקודה (צבירה)</th>
                <td>
                  <input type="number" step="1" min="1" name="<?php echo self::OPT_EARN_PER; ?>" value="<?php echo esc_attr($earn_p); ?>" /> ש״ח להזמנה = נקודה אחת
                  <p class="description">ברירת מחדל: 100 ש״ח להזמנה = נקודה אחת</p>
                </td>
              </tr>
            </table>
            <?php submit_button('שמור הגדרות'); ?>
          </form>

          <?php if ($ping): ?>
            <h2>סטטוס חיבור</h2>
            <?php if (!empty($ping['ok'])): ?>
              <p style="color:#0a7c45;font-weight:700">✓ חיבור תקין — TOPALENA הגיב</p>
            <?php else: ?>
              <p style="color:#c83a3a;font-weight:700">✗ חיבור נכשל (HTTP <?php echo (int)($ping['code'] ?? 0); ?>): <?php echo esc_html($ping['error'] ?? ''); ?></p>
              <p>בדוק: (1) הכתובת נכונה (2) מפתח API תואם בדיוק לערך ב-env של השרת.</p>
            <?php endif; ?>
          <?php endif; ?>
        </div>
        <?php
    }
}
