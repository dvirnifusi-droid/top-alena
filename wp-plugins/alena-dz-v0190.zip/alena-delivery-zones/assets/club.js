(function ($) {
  'use strict';
  $(document).on('click', '.alena-club-join-btn', function () {
    const $btn = $(this);
    if ($btn.prop('disabled')) return;
    const phone = $btn.data('phone');
    const nonce = $btn.data('nonce');
    if (!phone) return;
    const orig = $btn.text();
    $btn.prop('disabled', true).text('מצטרף…');
    $.post(window.ajaxurl || '/wp-admin/admin-ajax.php', {
      action: 'alena_club_register',
      phone:  phone,
      nonce:  nonce
    })
    .done(function (r) {
      if (r && r.success) {
        $btn.text('✓ הצטרפת!');
        setTimeout(function () { window.location.reload(); }, 700);
      } else {
        $btn.text(orig).prop('disabled', false);
        alert('שגיאה: ' + ((r && r.data) || 'unknown'));
      }
    })
    .fail(function () {
      $btn.text(orig).prop('disabled', false);
      alert('שגיאת רשת');
    });
  });
})(jQuery);
