(function ($) {
  'use strict';

  const $drawer   = $('#alena-drawer');
  const $backdrop = $('#alena-drawer-backdrop');
  const $body     = $('#alena-drawer-body');
  if (!$drawer.length) return;

  function open() {
    $drawer.removeAttr('hidden');
    $backdrop.removeAttr('hidden');
    setTimeout(() => { $drawer.addClass('open'); $backdrop.addClass('open'); }, 10);
    $('body').addClass('alena-drawer-open');
    refresh();
  }
  function close() {
    $drawer.removeClass('open');
    $backdrop.removeClass('open');
    setTimeout(() => { $drawer.attr('hidden', true); $backdrop.attr('hidden', true); }, 280);
    $('body').removeClass('alena-drawer-open');
  }
  function refresh() {
    $body.html('<div class="alena-drawer-skeleton">טוען…</div>');
    $.post(AlenaCartDrawer.ajaxUrl, {
      action: 'alena_cart_drawer',
      nonce:  AlenaCartDrawer.nonce
    }).done(function (r) {
      if (r && r.success) $body.html(r.data.html);
    }).fail(function () {
      $body.html('<div class="alena-drawer-empty">שגיאת טעינה</div>');
    });
  }

  // Open triggers — intercept clicks on the floating cart bar + top-nav cart
  $(document).on('click', '#alena-shop-cart-bar, a.alena-tn-link[href*="/cart"], a.alena-tn-cart-pill', function (e) {
    // Allow Ctrl/Cmd-click and middle-click to open full /cart page in new tab
    if (e.ctrlKey || e.metaKey || e.which === 2) return;
    e.preventDefault();
    open();
  });

  // Close triggers
  $(document).on('click', '#alena-drawer-close, #alena-drawer-backdrop', close);
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape' && $drawer.hasClass('open')) close();
  });

  // Stepper inside drawer (delegated)
  $body.on('click', '.alena-drawer-step-plus, .alena-drawer-step-minus', function () {
    const $btn   = $(this);
    const $item  = $btn.closest('.alena-drawer-item');
    const key    = $item.data('key');
    const $qtyEl = $item.find('.alena-drawer-step-qty');
    const isPlus = $btn.hasClass('alena-drawer-step-plus');
    const current = parseInt($qtyEl.text(), 10) || 0;
    const next = isPlus ? current + 1 : Math.max(0, current - 1);
    $qtyEl.text(next);
    $btn.prop('disabled', true);
    $.post('/?wc-ajax=update_cart_item_qty', { cart_item_key: key, quantity: next }, function () {
      refresh();
      $(document.body).trigger('updated_cart_totals');
    }).fail(function () {
      // Fallback: standard URL-based qty update
      window.location.reload();
    });
  });

  // Cross-sell — single tap add (only works for products without required mods).
  $body.on('click', '.alena-drawer-cross-card', function () {
    const $card = $(this);
    const pid = parseInt($card.data('product-id'), 10);
    if (!pid) return;
    $card.css('opacity', 0.5);
    const fd = new FormData();
    fd.append('product_id', pid);
    fd.append('quantity', '1');
    $.ajax({
      url: '/?wc-ajax=add_to_cart', type: 'POST', data: fd,
      processData: false, contentType: false, dataType: 'json'
    }).always(function () {
      refresh();
      $(document.body).trigger('added_to_cart');
    });
  });

  // Note chips
  $body.on('click', '.alena-drawer-chip', function () {
    const $chip = $(this);
    const text  = $chip.data('text');
    const $ta   = $('#alena-drawer-note-input');
    const cur   = ($ta.val() || '').trim();
    if (cur.indexOf(text) === -1) {
      $ta.val(cur ? cur + ' · ' + text : text);
      $chip.addClass('is-active');
    } else {
      $ta.val(cur.replace(new RegExp('\\s*·?\\s*' + text, 'g'), '').replace(/^·\s*/, '').trim());
      $chip.removeClass('is-active');
    }
    $ta.trigger('input');
  });

  // Persist note text to WC session via AJAX (debounced)
  let noteTimer = null;
  $body.on('input', '#alena-drawer-note-input', function () {
    clearTimeout(noteTimer);
    const val = $(this).val();
    noteTimer = setTimeout(() => {
      $.post(AlenaCartDrawer.ajaxUrl, { action: 'alena_cart_drawer_note', nonce: AlenaCartDrawer.nonce, note: val });
    }, 600);
  });
})(jQuery);
