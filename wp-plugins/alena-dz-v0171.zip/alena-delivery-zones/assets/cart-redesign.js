(function ($) {
  'use strict';

  // Animate qty change — pulse the total in summary
  $(document.body).on('updated_cart_totals', function () {
    const $total = $('.cart_totals .order-total .amount, .alena-cart-mega-total');
    if (!$total.length) return;
    $total.css('animation', 'none');
    void $total[0].offsetWidth; // reflow
    $total.css('animation', 'alena-cart-pulse 0.5s ease');
  });

  // Add a keyframe for pulse on the fly
  $('<style>').text(
    '@keyframes alena-cart-pulse { 0% { transform: scale(1); } 40% { transform: scale(1.10); color: #1e4a3a; } 100% { transform: scale(1); } }'
  ).appendTo('head');

  // Smooth AJAX remove — intercept the default WC × link, fade+slide the row, reload to refresh totals
  $(document).on('click', '.woocommerce-cart td.product-remove a.remove', function (e) {
    e.preventDefault();
    const $link = $(this);
    const $row  = $link.closest('tr');
    const url   = $link.attr('href');
    if (!url || $link.data('removing')) return;
    $link.data('removing', 1);
    $row.css({ 'pointer-events': 'none', 'transition': 'opacity .2s', 'opacity': '0.35' });
    $.ajax({ url: url, type: 'GET' })
      .done(function () {
        $row.slideUp(260, function () { window.location.reload(); });
      })
      .fail(function () {
        $row.css({ 'pointer-events': 'auto', 'opacity': '1' });
        $link.removeData('removing');
        alert('שגיאה במחיקה, נסו שוב');
      });
  });
})(jQuery);
