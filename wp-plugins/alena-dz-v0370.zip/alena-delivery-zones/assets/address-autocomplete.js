/**
 * Google Places autocomplete on the checkout street field.
 *
 * The point is not convenience — it is that the string reaching the geocoder is
 * one that actually resolves. Freehand text like "hrzael 34" produced no
 * delivery rate at all, which silently blocked the order.
 */
(function ($) {
  'use strict';

  var ac = null;

  function field() {
    return document.querySelector('#billing_address_1, #shipping_address_1');
  }

  function setStatus(msg, kind) {
    var el = document.getElementById('alena-addr-status');
    if (!el) {
      var f = field();
      if (!f) return;
      el = document.createElement('div');
      el.id = 'alena-addr-status';
      f.parentNode.appendChild(el);
    }
    el.className = 'alena-addr-status' + (kind ? ' is-' + kind : '');
    el.textContent = msg || '';
    el.hidden = !msg;
  }

  function sendCoords(lat, lng) {
    return $.post(AlenaAddr.ajaxUrl, {
      action: 'alena_addr_coords',
      nonce: AlenaAddr.nonce,
      lat: lat || '',
      lng: lng || ''
    });
  }

  function part(place, type, useShort) {
    var c = (place.address_components || []).find(function (x) {
      return x.types.indexOf(type) !== -1;
    });
    return c ? (useShort ? c.short_name : c.long_name) : '';
  }

  function onPick() {
    var place = ac.getPlace();
    if (!place || !place.geometry) {
      // The customer typed and pressed enter without choosing a suggestion —
      // there is no resolved address behind it, so do not pretend there is.
      sendCoords('', '');
      setStatus('בחרו כתובת מהרשימה כדי שנוכל לבדוק שאנחנו מגיעים אליכם', 'warn');
      return;
    }

    var street = part(place, 'route');
    var number = part(place, 'street_number');
    var city   = part(place, 'locality') || part(place, 'administrative_area_level_2');
    var line   = (street + ' ' + number).trim() || place.name || '';

    var f = field();
    if (f && line) {
      f.value = line;
      $(f).trigger('change');
    }
    var cityField = document.querySelector('#billing_city, #shipping_city');
    if (cityField && city) {
      cityField.value = city;
      $(cityField).trigger('change');
    }

    var lat = place.geometry.location.lat();
    var lng = place.geometry.location.lng();

    setStatus('בודקים אם אנחנו מגיעים לכתובת…', '');
    sendCoords(lat, lng).always(function () {
      setStatus('✓ ' + line + (city ? ', ' + city : ''), 'ok');
      // Recalculate shipping now that a real location is known.
      $(document.body).trigger('update_checkout');
    });

    if (!number) {
      setStatus('חסר מספר בית — הוסיפו אותו כדי שהשליח ימצא אתכם', 'warn');
    }
  }

  function attach() {
    var f = field();
    if (!f || f.dataset.alenaAc === '1') return;
    if (!(window.google && google.maps && google.maps.places)) return;

    f.dataset.alenaAc = '1';
    f.setAttribute('autocomplete', 'off');       // let Places own the dropdown
    f.setAttribute('placeholder', 'התחילו להקליד רחוב ומספר…');

    var opts = {
      componentRestrictions: { country: 'il' },
      fields: ['address_components', 'geometry', 'name'],
      types: ['address']
    };
    if (AlenaAddr.center && AlenaAddr.center.lat) {
      var c = new google.maps.LatLng(AlenaAddr.center.lat, AlenaAddr.center.lng);
      opts.bounds = new google.maps.Circle({ center: c, radius: 15000 }).getBounds();
      opts.strictBounds = false;
    }

    ac = new google.maps.places.Autocomplete(f, opts);
    ac.addListener('place_changed', onPick);

    // Enter on the suggestion list must not submit the checkout form.
    f.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && document.querySelector('.pac-container:not([style*="display: none"])')) {
        e.preventDefault();
      }
    });

    // Typing after a pick invalidates the stored coordinates.
    f.addEventListener('input', function () {
      if (f.dataset.alenaPicked === '1') {
        f.dataset.alenaPicked = '0';
        sendCoords('', '');
        setStatus('');
      }
    });
  }

  // Google calls this once the Maps script finishes loading.
  window.alenaAddrInit = function () { attach(); };

  $(function () {
    attach();
    // WooCommerce replaces the checkout form on every update; re-attach after.
    $(document.body).on('updated_checkout', attach);
  });
})(jQuery);
