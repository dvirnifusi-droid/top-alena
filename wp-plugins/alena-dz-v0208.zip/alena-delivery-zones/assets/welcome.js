(function ($) {
  'use strict';

  const $welcome = $('#alena-welcome');
  if (!$welcome.length) return;

  $('body').addClass('alena-welcome-active');

  let chosenMode = 'delivery';

  function setMode(m) {
    chosenMode = m;
    $('.alena-welcome-mode').removeClass('is-active').filter('[data-mode="' + m + '"]').addClass('is-active');
    const isDelivery = (m === 'delivery');
    $('#alena-welcome-address').attr('hidden', !isDelivery);
    if (isDelivery) {
      setTimeout(function () { $('#alena-welcome-address-input').trigger('focus'); }, 80);
    }
  }
  setMode(chosenMode);

  $welcome.on('click', '.alena-welcome-mode', function () {
    setMode($(this).data('mode'));
  });

  // Step 1 → Step 2
  $welcome.on('click', '#alena-welcome-next', function () {
    const $btn   = $(this);
    const address = ($('#alena-welcome-address-input').val() || '').trim();
    if (chosenMode === 'delivery' && address.length < 5) {
      $('#alena-welcome-address-input').trigger('focus').css('border-color', '#c83a3a');
      return;
    }
    const orig = $btn.text();
    $btn.prop('disabled', true).text('שומר…');
    $.post(AlenaWelcome.ajaxUrl, {
      action:  'alena_welcome_save',
      nonce:   AlenaWelcome.nonce,
      mode:    chosenMode,
      address: address
    }).always(function () {
      // Move to step 2 whether the save succeeded or not — fail-soft
      $btn.prop('disabled', false).text(orig);
      $welcome.find('[data-step="1"]').attr('hidden', true);
      $welcome.find('[data-step="2"]').removeAttr('hidden');
    });
  });

  // Step 2: 3 options — always the same UI, but logged-in users skip the OTP flow
  $welcome.on('click', '.alena-welcome-option', function () {
    const action = $(this).data('action');
    if (!action) return;

    if (action === 'login' || action === 'register') {
      // Already authenticated? skip the OTP page and go straight to the menu —
      // the banner on /shop will tell them what they have.
      if (AlenaWelcome.isLoggedIn) {
        window.location.href = AlenaWelcome.shopUrl;
        return;
      }
      // Guests: route by intent — register goes to the form with name + consent,
      // login goes straight to the phone-only flow.
      const url = AlenaWelcome.accountUrl + (action === 'register' ? '?mode=register' : '');
      window.location.href = url;
      return;
    }
    // skip → straight to the menu as a guest
    window.location.href = AlenaWelcome.shopUrl;
  });

  $('#alena-welcome-address-input').on('input', function () {
    $(this).css('border-color', '');
  });
})(jQuery);
