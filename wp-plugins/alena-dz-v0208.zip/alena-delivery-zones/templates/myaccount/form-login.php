<?php
/**
 * Phone+OTP login / registration template — overrides WC's default form-login.php
 *
 * Three modes (set via JS, determined by ?mode= URL param):
 *   - login    (default): just phone → code → done
 *   - register: name + phone + marketing consent → code → done (also POSTs to club register)
 *
 * Powered by the REST endpoints in class-phone-auth.php.
 */
if (!defined('ABSPATH')) exit;

$mode_param = isset($_GET['mode']) ? sanitize_text_field((string) $_GET['mode']) : 'login';
$is_register = ($mode_param === 'register');

do_action('woocommerce_before_customer_login_form');
?>

<div class="alena-otp-wrap" dir="rtl" data-mode="<?php echo esc_attr($is_register ? 'register' : 'login'); ?>">
  <div class="alena-otp-card">
    <div class="alena-otp-emoji" aria-hidden="true">📱</div>

    <!-- Mode toggle: login | register -->
    <div class="alena-otp-tabs" role="tablist">
      <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>"
         class="alena-otp-tab <?php echo !$is_register ? 'is-active' : ''; ?>"
         data-mode="login">התחברות</a>
      <a href="<?php echo esc_url(add_query_arg('mode', 'register', wc_get_page_permalink('myaccount'))); ?>"
         class="alena-otp-tab <?php echo $is_register ? 'is-active' : ''; ?>"
         data-mode="register">הרשמה למועדון</a>
    </div>

    <h2 class="alena-otp-title">
      <?php echo $is_register ? 'הרשמה למועדון עלינא' : 'התחברות מהירה'; ?>
    </h2>
    <p class="alena-otp-sub">
      <?php echo $is_register
        ? 'מילוי קצר, צבירה בכל הזמנה, הטבות אישיות ליום הולדת ולחגים'
        : 'תכניסו טלפון, נשלח לכם קוד בוואטסאפ'; ?>
    </p>

    <!-- Step 1: phone (and name + consent on register) -->
    <form class="alena-otp-form" id="alena-otp-step-phone" autocomplete="off" novalidate>
      <?php if ($is_register): ?>
      <label class="alena-otp-label">שם פרטי
        <input type="text"
               name="name"
               id="alena-otp-name"
               placeholder="לדוגמה: דנה"
               autocomplete="given-name"
               required />
      </label>
      <?php endif; ?>

      <label class="alena-otp-label">מספר טלפון
        <input type="tel"
               inputmode="tel"
               name="phone"
               id="alena-otp-phone"
               placeholder="050-1234567"
               autocomplete="tel"
               required
               dir="ltr" />
      </label>

      <?php if ($is_register): ?>
      <label class="alena-otp-consent">
        <input type="checkbox" id="alena-otp-consent" checked />
        <span>מסכים/ה לקבל הטבות והודעות שיווקיות בוואטסאפ / SMS</span>
      </label>
      <?php endif; ?>

      <button type="submit" class="alena-otp-cta">
        <?php echo $is_register ? 'שלחו לי קוד ←' : 'שלחו לי קוד ←'; ?>
      </button>
      <p class="alena-otp-error" id="alena-otp-phone-error" hidden></p>
    </form>

    <!-- Step 2: code -->
    <form class="alena-otp-form" id="alena-otp-step-code" autocomplete="off" novalidate hidden>
      <p class="alena-otp-step-info">
        שלחנו קוד 6 ספרות ל-<strong id="alena-otp-shown-phone"></strong>
        · <a href="#" id="alena-otp-change-phone">שנה מספר</a>
      </p>
      <label class="alena-otp-label">קוד אימות
        <input type="text"
               inputmode="numeric"
               pattern="\d{6}"
               maxlength="6"
               name="code"
               id="alena-otp-code"
               placeholder="123456"
               autocomplete="one-time-code"
               required
               dir="ltr" />
      </label>
      <button type="submit" class="alena-otp-cta"><?php echo $is_register ? 'הצטרף ✓' : 'התחבר ✓'; ?></button>
      <p class="alena-otp-meta">
        לא קיבלתם? <a href="#" id="alena-otp-resend">שלחו שוב</a>
        <span id="alena-otp-cooldown" hidden> · בעוד <span id="alena-otp-cooldown-sec">60</span> שניות</span>
      </p>
      <p class="alena-otp-error" id="alena-otp-code-error" hidden></p>
    </form>

    <p class="alena-otp-legal">
      בהמשך אתם מסכימים ל<a href="<?php echo esc_url(get_privacy_policy_url() ?: '#'); ?>">תקנון ומדיניות הפרטיות</a>
    </p>
  </div>
</div>

<?php do_action('woocommerce_after_customer_login_form'); ?>
