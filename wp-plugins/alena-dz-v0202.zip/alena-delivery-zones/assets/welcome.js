(function ($) {
  'use strict';

  const STORAGE_KEY = 'alena_welcome_done_v1';
  const $overlay = $('#alena-welcome');
  if (!$overlay.length) return;

  // Skip if already completed in this browser
  try { if (sessionStorage.getItem(STORAGE_KEY) === '1') return; } catch (e) {}

  // Show
  $overlay.removeAttr('hidden');
  $('body').addClass('alena-welcome-open');

  let chosenMode = 'delivery'; // default highlighted

  function setMode(m) {
    chosenMode = m;
    $('.alena-welcome-mode').removeClass('is-active').filter('[data-mode="' + m + '"]').addClass('is-active');
    $('#alena-welcome-address').attr('hidden', m !== 'delivery');
    if (m === 'delivery') {
      // brief delay so the input is visible before focusing
      setTimeout(function () { $('#alena-welcome-address-input').trigger('focus'); }, 60);
    }
  }

  // Initial state
  setMode(chosenMode);

  // Mode picker
  $overlay.on('click', '.alena-welcome-mode', function () {
    setMode($(this).data('mode'));
  });

  // Step 1 → Step 2
  $overlay.on('click', '#alena-welcome-next', function () {
    const $btn   = $(this);
    const address = ($('#alena-welcome-address-input').val() || '').trim();
    if (chosenMode === 'delivery' && address.length < 5) {
      $('#alena-welcome-address-input').trigger('focus').css('border-color', '#c83a3a');
      return;
    }
    const orig = $btn.text();
    $btn.prop('disabled', true).text('…');
    $.post(AlenaWelcome.ajaxUrl, {
      action:  'alena_welcome_save',
      nonce:   AlenaWelcome.nonce,
      mode:    chosenMode,
      address: address
    }).done(function () {
      $btn.prop('disabled', false).text(orig);
      $overlay.find('[data-step="1"]').attr('hidden', true);
      $overlay.find('[data-step="2"]').removeAttr('hidden');
    }).fail(function () {
      $btn.prop('disabled', false).text(orig);
      // Allow the user to proceed even if the AJAX failed — fail-soft
      $overlay.find('[data-step="1"]').attr('hidden', true);
      $overlay.find('[data-step="2"]').removeAttr('hidden');
    });
  });

  // Step 2: club options
  $overlay.on('click', '.alena-welcome-option', function () {
    const action = $(this).data('action');
    try { sessionStorage.setItem(STORAGE_KEY, '1'); } catch (e) {}

    if (action === 'login' || action === 'register') {
      window.location.href = AlenaWelcome.accountUrl;
      return;
    }
    // skip — dismiss overlay and stay on shop
    dismiss();
  });

  function dismiss() {
    try { sessionStorage.setItem(STORAGE_KEY, '1'); } catch (e) {}
    $overlay.fadeOut(220, function () {
      $('body').removeClass('alena-welcome-open');
      $overlay.attr('hidden', true);
    });
  }

  // Esc to dismiss
  $(document).on('keydown.alena-welcome', function (e) {
    if (e.key === 'Escape' && !$overlay.is(':hidden')) {
      dismiss();
      $(document).off('keydown.alena-welcome');
    }
  });

  // Clear red border when user types
  $('#alena-welcome-address-input').on('input', function () {
    $(this).css('border-color', '');
  });
})(jQuery);
