<?php
if (!defined('ABSPATH')) exit;

/**
 * Welcome / onboarding overlay shown to first-time visitors.
 *
 * Two steps:
 *   1. Pick fulfillment (delivery vs pickup) + address (if delivery)
 *   2. Club options: login / register / continue as guest
 *
 * Persists the choice in WC session so checkout pre-fills it, and in a
 * sessionStorage flag so it doesn't re-appear on every page navigation.
 */
class Alena_DZ_Welcome {

    const SESS_KEY_MODE     = 'alena_fulfillment_mode';
    const SESS_KEY_ADDRESS  = 'alena_initial_address';

    public function __construct() {
        add_action('wp_footer',                        [$this, 'render']);
        add_action('wp_enqueue_scripts',               [$this, 'enqueue']);
        add_action('wp_ajax_alena_welcome_save',       [$this, 'ajax_save']);
        add_action('wp_ajax_nopriv_alena_welcome_save',[$this, 'ajax_save']);
    }

    public function enqueue() {
        if (is_admin()) return;
        wp_enqueue_style('alena-welcome',  ALENA_DZ_URL . 'assets/welcome.css', [], ALENA_DZ_VERSION);
        wp_enqueue_script('alena-welcome', ALENA_DZ_URL . 'assets/welcome.js',  ['jquery'], ALENA_DZ_VERSION, true);
        wp_localize_script('alena-welcome', 'AlenaWelcome', [
            'ajaxUrl'  => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('alena_welcome'),
            'shopUrl'  => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '/shop/',
            'accountUrl' => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : '/my-account/',
        ]);
    }

    public function render() {
        if (is_admin()) return;
        // Show only on shop/home — not on checkout/cart/account where it'd disrupt
        if (function_exists('is_checkout') && (is_checkout() || (function_exists('is_cart') && is_cart()) || (function_exists('is_account_page') && is_account_page()))) return;

        $site_icon = get_site_icon_url(160);
        ?>
        <div class="alena-welcome-overlay" id="alena-welcome" hidden>
          <div class="alena-welcome-card">

            <div class="alena-welcome-logo">
              <?php if ($site_icon): ?>
                <img src="<?php echo esc_url($site_icon); ?>" alt="עלינא בפיתה" />
              <?php else: ?>
                <div class="alena-welcome-mark">עלינא</div>
              <?php endif; ?>
              <div class="alena-welcome-tagline">מטבח ים-תיכוני שמח וצבעוני</div>
            </div>

            <!-- Step 1: fulfillment + address -->
            <div class="alena-welcome-step" data-step="1">
              <h2 class="alena-welcome-title">ברוכים הבאים!</h2>
              <p class="alena-welcome-sub">איך תעדיפו לקבל את ההזמנה?</p>

              <div class="alena-welcome-modes">
                <button type="button" class="alena-welcome-mode" data-mode="pickup">
                  <span class="alena-welcome-mode-icon" aria-hidden="true">🥡</span>
                  <span class="alena-welcome-mode-label">איסוף עצמי</span>
                  <span class="alena-welcome-mode-sub">~15-25 דק'</span>
                </button>
                <button type="button" class="alena-welcome-mode is-active" data-mode="delivery">
                  <span class="alena-welcome-mode-icon" aria-hidden="true">🛵</span>
                  <span class="alena-welcome-mode-label">משלוח</span>
                  <span class="alena-welcome-mode-sub">~40-60 דק'</span>
                </button>
              </div>

              <div class="alena-welcome-address" id="alena-welcome-address">
                <label for="alena-welcome-address-input">כתובת מלאה למשלוח</label>
                <input type="text"
                       id="alena-welcome-address-input"
                       placeholder="לדוגמה: הרצל 123, ראשון לציון"
                       autocomplete="street-address" />
                <p class="alena-welcome-address-hint">משלוחים לראשון לציון, משמר השבעה ובית דגן</p>
              </div>

              <button type="button" class="alena-welcome-next" id="alena-welcome-next">המשך</button>
            </div>

            <!-- Step 2: club -->
            <div class="alena-welcome-step" data-step="2" hidden>
              <h2 class="alena-welcome-title">התחברות למערכת</h2>
              <p class="alena-welcome-sub">חברי מועדון צוברים ופודים בכל הזמנה — בחר איך להתחיל</p>

              <button type="button" class="alena-welcome-option" data-action="login">
                <span class="alena-welcome-option-icon" aria-hidden="true">📱</span>
                <span class="alena-welcome-option-label">התחברות כחבר מועדון</span>
              </button>
              <button type="button" class="alena-welcome-option" data-action="register">
                <span class="alena-welcome-option-icon" aria-hidden="true">📝</span>
                <span class="alena-welcome-option-label">הרשמה למועדון הלקוחות</span>
              </button>
              <button type="button" class="alena-welcome-option alena-welcome-option-ghost" data-action="skip">
                <span class="alena-welcome-option-icon" aria-hidden="true">→</span>
                <span class="alena-welcome-option-label">המשך ללא התחברות</span>
              </button>
            </div>

          </div>
        </div>
        <?php
    }

    public function ajax_save() {
        check_ajax_referer('alena_welcome', 'nonce');
        $mode    = isset($_POST['mode']) ? sanitize_text_field((string) $_POST['mode']) : '';
        $address = isset($_POST['address']) ? sanitize_text_field((string) $_POST['address']) : '';
        if (!in_array($mode, ['delivery', 'pickup'], true)) {
            wp_send_json_error('bad_mode', 400);
        }
        if (function_exists('WC') && WC()->session) {
            WC()->session->set(self::SESS_KEY_MODE,    $mode);
            WC()->session->set(self::SESS_KEY_ADDRESS, $address);
            // Also feed into the existing fulfillment system if present
            $methods = ($mode === 'pickup') ? ['local_pickup'] : ['alena_polygon'];
            WC()->session->set('chosen_shipping_methods', $methods);
        }
        wp_send_json_success(['mode' => $mode]);
    }
}
