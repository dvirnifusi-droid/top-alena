<?php
/**
 * Plugin Name: Alena Delivery Zones
 * Description: Google Maps polygon-based delivery zones for WooCommerce. Owner draws delivery polygons on a map; the plugin adds a WC shipping method that geocodes the customer address and matches it to the right polygon (fee, min-order).
 * Version: 0.21.3
 * Author: Alena / TOPALENA
 * Requires PHP: 7.4
 * Requires at least: 6.5
 * WC tested up to: 9.9
 * Text Domain: alena-dz
 */

if (!defined('ABSPATH')) exit;

define('ALENA_DZ_VERSION', '0.21.3');
define('ALENA_DZ_PATH', plugin_dir_path(__FILE__));
define('ALENA_DZ_URL',  plugin_dir_url(__FILE__));

require_once ALENA_DZ_PATH . 'includes/class-polygon-store.php';
require_once ALENA_DZ_PATH . 'includes/class-geocoder.php';
require_once ALENA_DZ_PATH . 'includes/class-admin.php';
require_once ALENA_DZ_PATH . 'includes/class-checkout-fields.php';
require_once ALENA_DZ_PATH . 'includes/class-checkout-map.php';
require_once ALENA_DZ_PATH . 'includes/class-hours-engine.php';
require_once ALENA_DZ_PATH . 'includes/class-hours-admin.php';
require_once ALENA_DZ_PATH . 'includes/class-hours-checkout.php';
require_once ALENA_DZ_PATH . 'includes/class-wolt-importer.php';
require_once ALENA_DZ_PATH . 'includes/class-shop-styling.php';
require_once ALENA_DZ_PATH . 'includes/class-modifiers.php';
require_once ALENA_DZ_PATH . 'includes/class-cart-enhancements.php';
require_once ALENA_DZ_PATH . 'includes/class-mobile-ux.php';
require_once ALENA_DZ_PATH . 'includes/class-thank-you.php';
require_once ALENA_DZ_PATH . 'includes/class-order-scheduling.php';
require_once ALENA_DZ_PATH . 'includes/class-pwa.php';
require_once ALENA_DZ_PATH . 'includes/class-cart-redesign.php';
require_once ALENA_DZ_PATH . 'includes/class-checkout-redesign.php';
require_once ALENA_DZ_PATH . 'includes/class-top-nav.php';
require_once ALENA_DZ_PATH . 'includes/class-recent-orders.php';
require_once ALENA_DZ_PATH . 'includes/class-club.php';
require_once ALENA_DZ_PATH . 'includes/class-phone-auth.php';
require_once ALENA_DZ_PATH . 'includes/class-welcome.php';

add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Alena Delivery Zones</strong> requires WooCommerce to be active.</p></div>';
        });
        return;
    }
    new Alena_DZ_Admin();
    new Alena_DZ_Manager();
    new Alena_DZ_Checkout_Fields();
    new Alena_DZ_Checkout_Map();
    new Alena_DZ_Hours_Admin();
    new Alena_DZ_Hours_Checkout();
    new Alena_DZ_Wolt_Importer();
    new Alena_DZ_Shop_Styling();
    new Alena_DZ_Modifiers();
    new Alena_DZ_Cart_Enhancements();
    new Alena_DZ_Mobile_UX();
    new Alena_DZ_Thank_You();
    new Alena_DZ_Order_Scheduling();
    new Alena_DZ_PWA();
    new Alena_DZ_Cart_Redesign();
    new Alena_DZ_Checkout_Redesign();
    new Alena_DZ_Top_Nav();
    new Alena_DZ_Recent_Orders();
    new Alena_DZ_Club();
    new Alena_DZ_Phone_Auth();
    new Alena_DZ_Welcome();
});

register_activation_hook(__FILE__, function () {
    // Flush rewrites so the PWA manifest/SW endpoints are reachable
    flush_rewrite_rules();
});

// Force the WooCommerce "Coming Soon" gate OFF — the shop must be public for customers.
// Intercept the option READ so it always returns 'no', regardless of what's stored in DB.
// Also overwrite the DB value once on plugin load so admin UI reflects reality.
add_filter('pre_option_woocommerce_coming_soon',     function () { return 'no'; });
add_filter('pre_option_woocommerce_store_pages_only', function () { return 'no'; });
add_filter('pre_option_woocommerce_private_link',     function () { return 'no'; });
add_action('plugins_loaded', function () {
    update_option('woocommerce_coming_soon',      'no');
    update_option('woocommerce_store_pages_only', 'no');
    update_option('woocommerce_private_link',     'no');
}, 1);

// Shipping method (class loads only after WC is ready)
add_action('woocommerce_shipping_init', function () {
    require_once ALENA_DZ_PATH . 'includes/class-shipping-method.php';
});

add_filter('woocommerce_shipping_methods', function ($methods) {
    $methods['alena_polygon'] = 'Alena_DZ_Shipping_Method';
    return $methods;
});

// SEO: consolidate brand authority around alena.topalena.com (showcase site)
add_action('wp_head', function () {
    echo "\n" . '<link rel="me" href="https://alena.topalena.com" />' . "\n";
    echo '<meta property="og:see_also" content="https://alena.topalena.com" />' . "\n";
}, 1);

// Footer banner pointing to the showcase site
add_action('wp_footer', function () {
    if (is_admin()) return;
    ?>
    <a href="https://alena.topalena.com" rel="noopener" id="alena-official-link"
       style="display:block;text-align:center;padding:18px 14px;background:linear-gradient(135deg,#1F1B17,#44512C);
              color:#F4ECD8;font-family:'Heebo',sans-serif;font-size:14px;text-decoration:none;
              border-top:3px solid #B89556;letter-spacing:0.02em;line-height:1.5">
      <span style="font-size:11px;letter-spacing:0.3em;text-transform:uppercase;color:#D9BD83;display:block;margin-bottom:4px">
        האתר הרשמי
      </span>
      <b style="color:#F4ECD8;font-size:18px">alena.topalena.com</b>
      <span style="display:block;font-size:13px;color:rgba(244,236,216,0.8);margin-top:4px">
        תפריט מלא · אירועים פרטיים · הזמנת שולחן · בלוג
      </span>
    </a>
    <?php
});

// Register the Google API key options for settings_fields()
add_action('admin_init', function () {
    register_setting('alena_dz', 'alena_dz_google_key', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    register_setting('alena_dz', 'alena_dz_google_server_key', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
});
