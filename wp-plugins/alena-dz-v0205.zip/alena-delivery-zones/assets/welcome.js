(function ($) {
  'use strict';

  const $welcome = $('#alena-welcome');
  if (!$welcome.length) return;

  $('body').addClass('alena-welcome-active');

  let chosenMode = 'delivery';

  function setMode(m) {
    chosenMode = m;
    $('.alena-welcome-mode').removeClass('is-active').filter('[data-mode="' + m + '"]').addClass('is-active');
    const isDelivery = (m === 'delivery');
    $('#alena-welcome-address').attr('hidden', !isDelivery);
    if (isDelivery) {
      setTimeout(function () { $('#alena-welcome-address-input').trigger('focus'); }, 80);
    }
  }
  setMode(chosenMode);

  $welcome.on('click', '.alena-welcome-mode', function () {
    setMode($(this).data('mode'));
  });

  // Step 1 → Step 2
  $welcome.on('click', '#alena-welcome-next', function () {
    const $btn   = $(this);
    const address = ($('#alena-welcome-address-input').val() || '').trim();
    if (chosenMode === 'delivery' && address.length < 5) {
      $('#alena-welcome-address-input').trigger('focus').css('border-color', '#c83a3a');
      return;
    }
    const orig = $btn.text();
    $btn.prop('disabled', true).text('שומר…');
    $.post(AlenaWelcome.ajaxUrl, {
      action:  'alena_welcome_save',
      nonce:   AlenaWelcome.nonce,
      mode:    chosenMode,
      address: address
    }).always(function () {
      // Move to step 2 whether the save succeeded or not — fail-soft
      $btn.prop('disabled', false).text(orig);
      $welcome.find('[data-step="1"]').attr('hidden', true);
      $welcome.find('[data-step="2"]').removeAttr('hidden');
    });
  });

  // Step 2: club options + continue-to-shop for logged-in users
  $welcome.on('click', '.alena-welcome-option, .alena-welcome-next[data-action]', function () {
    const action = $(this).data('action');
    if (!action) return;
    if (action === 'login' || action === 'register') {
      window.location.href = AlenaWelcome.accountUrl;
      return;
    }
    if (action === 'logout') {
      window.location.href = AlenaWelcome.accountUrl + '?logout=1';
      return;
    }
    // skip OR continue-to-shop — both go straight to /shop (server already has the fulfillment mode set)
    window.location.href = AlenaWelcome.shopUrl;
  });

  $('#alena-welcome-address-input').on('input', function () {
    $(this).css('border-color', '');
  });
})(jQuery);
